<?php
/**
 * QuarryForce API Router - PHP Backend
 * 
 * Main router for all API endpoints
 * Routes all requests to appropriate handlers
 * Integrated with Logger for comprehensive logging
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/Database.php';

// Init response headers
header('Content-Type: application/json; charset=utf-8');

// CORS Headers
$allowed_origins = [
    'https://valviyal.com',
    'http://localhost:3000',
    'http://localhost:19006',
    'http://localhost:8081',
    '*'
];

$origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
if (in_array($origin, $allowed_origins) || in_array('*', $allowed_origins)) {
    header('Access-Control-Allow-Origin: ' . $origin);
}

header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS, PATCH');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Get request path and method
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = str_replace('/qft/api', '', $path);
$path = str_replace('/api', '', $path);
$path = rtrim($path, '/') ?: '/';

// Fallback: check for request query parameter (from .htaccess rewrite)
if ($path === '/' && isset($_GET['request'])) {
    $request = $_GET['request'];
    $request = str_replace('api/', '', $request);
    $request = str_replace('api', '', $request);
    $path = '/' . trim($request, '/');
    $path = $path === '/' ? '/' : $path;
}

// Parse query/body
$input = [];
if ($method === 'GET') {
    $input = $_GET;
} else {
    $raw = file_get_contents('php://input');
    if (!empty($raw)) {
        $input = json_decode($raw, true) ?? [];
    }
}

Logger::logRequest($path, $method, count($input) > 0 ? array_slice($input, 0, 3) : null);

// ==========================================
// ROUTING
// ==========================================

try {
    // ROOT ROUTE
    if ($path === '/' && $method === 'GET') {
        handleRoot();
    }
    // SETTINGS
    elseif ($path === '/settings' && $method === 'GET') {
        handleSettingsGet();
    }
    elseif ($path === '/settings' && $method === 'PUT') {
        handleSettingsPut($input);
    }
    // LOGIN
    elseif ($path === '/login' && $method === 'POST') {
        handleLogin($input);
    }
    // CHECK-IN
    elseif ($path === '/checkin' && $method === 'POST') {
        handleCheckin($input);
    }
    // VISIT
    elseif ($path === '/visit/submit' && $method === 'POST') {
        handleVisitSubmit($input);
    }
    // FUEL
    elseif ($path === '/fuel/submit' && $method === 'POST') {
        handleFuelSubmit($input);
    }
    // ADMIN - REPS
    elseif ($path === '/admin/reps' && $method === 'GET') {
        handleAdminReps();
    }
    // ADMIN - CUSTOMERS
    elseif ($path === '/admin/customers' && $method === 'GET') {
        handleAdminCustomers();
    }
    // ADMIN - RESET DEVICE
    elseif ($path === '/admin/reset-device' && $method === 'POST') {
        handleAdminResetDevice($input);
    }
    // ADMIN - REP TARGETS
    elseif (preg_match('#^/admin/rep-targets(/(\d+))?$#', $path, $matches) && $method === 'GET') {
        $repId = $matches[2] ?? null;
        if ($repId) {
            handleAdminRepTargetsGet($repId);
        } else {
            handleAdminRepTargetsList();
        }
    }
    elseif ($path === '/admin/rep-targets' && $method === 'POST') {
        handleAdminRepTargetsCreate($input);
    }
    elseif (preg_match('#^/admin/rep-targets/(\d+)$#', $path, $matches) && $method === 'PUT') {
        handleAdminRepTargetsUpdate($matches[1], $input);
    }
    // ADMIN - REP PROGRESS
    elseif (preg_match('#^/admin/rep-progress/(\d+)$#', $path, $matches) && $method === 'GET') {
        $repId = $matches[1];
        $month = $_GET['month'] ?? null;
        handleAdminRepProgress($repId, $month);
    }
    elseif (preg_match('#^/admin/rep-progress-history/(\d+)$#', $path, $matches) && $method === 'GET') {
        handleAdminRepProgressHistory($matches[1]);
    }
    // ADMIN - REP PROGRESS UPDATE
    elseif ($path === '/admin/rep-progress/update' && $method === 'POST') {
        handleAdminRepProgressUpdate($input);
    }
    // ADMIN - USERS
    elseif ($path === '/admin/users' && $method === 'GET') {
        handleAdminUsersList();
    }
    elseif ($path === '/admin/users' && $method === 'POST') {
        handleAdminUsersCreate($input);
    }
    elseif (preg_match('#^/admin/users/(\d+)$#', $path, $matches) && $method === 'PUT') {
        $userId = $matches[1];
        // Check if it's device-uid endpoint
        if (isset($_GET['action']) && $_GET['action'] === 'set-device') {
            handleAdminUsersSetDevice($userId, $input);
        } else {
            handleAdminUsersUpdate($userId, $input);
        }
    }
    elseif (preg_match('#^/admin/users/(\d+)/device-uid$#', $path, $matches) && $method === 'PUT') {
        handleAdminUsersSetDevice($matches[1], $input);
    }
    elseif (preg_match('#^/admin/users/(\d+)$#', $path, $matches) && $method === 'DELETE') {
        handleAdminUsersDelete($matches[1]);
    }
    // TEST ROUTE
    elseif ($path === '/test' && $method === 'GET') {
        handleTest();
    }
    // 404 - Not Found
    else {
        http_response_code(404);
        Logger::logResponse($path, 404);
        jsonResponse(['success' => false, 'error' => 'Endpoint not found']);
    }

} catch (Exception $e) {
    Logger::error('Unhandled exception', ['path' => $path, 'error' => $e->getMessage()]);
    http_response_code(500);
    Logger::logResponse($path, 500);
    jsonResponse(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}

// ==========================================
// ENDPOINT HANDLERS
// ==========================================

/**
 * GET /
 * Root endpoint - API information
 */
function handleRoot() {
    Logger::debug('Root endpoint accessed');
    $response = [
        'success' => true,
        'message' => 'QuarryForce Backend API',
        'version' => '2.0.0',
        'status' => 'Online',
        'apis' => [
            'settings' => 'GET|PUT /api/settings',
            'login' => 'POST /api/login',
            'checkin' => 'POST /api/checkin',
            'visit' => 'POST /api/visit/submit',
            'fuel' => 'POST /api/fuel/submit',
            'admin_reps' => 'GET /api/admin/reps',
            'admin_customers' => 'GET /api/admin/customers',
            'admin_reset' => 'POST /api/admin/reset-device',
            'admin_rep_targets_all' => 'GET /api/admin/rep-targets',
            'admin_rep_targets_get' => 'GET /api/admin/rep-targets/:rep_id',
            'admin_rep_targets_create' => 'POST /api/admin/rep-targets',
            'admin_rep_targets_update' => 'PUT /api/admin/rep-targets/:id',
            'admin_rep_progress' => 'GET /api/admin/rep-progress/:rep_id',
            'admin_rep_sales_update' => 'POST /api/admin/rep-progress/update',
            'admin_users' => 'GET|POST|PUT|DELETE /api/admin/users',
            'health' => 'GET /api/test'
        ]
    ];
    Logger::logResponse('/', 200, ['message' => 'API info']);
    jsonResponse($response);
}

/**
 * GET /settings
 * Get system settings
 */
function handleSettingsGet() {
    Logger::debug('Fetching system settings');
    try {
        $db = new Database();
        $settings = $db->queryOne('SELECT * FROM system_settings LIMIT 1', []);
        
        Logger::logResponse('/settings', 200);
        jsonResponse(['success' => true, 'data' => $settings]);
    } catch (Exception $e) {
        Logger::error('Failed to fetch settings', ['error' => $e->getMessage()]);
        Logger::logResponse('/settings', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * PUT /settings
 * Update system settings
 */
function handleSettingsPut($input) {
    Logger::info('Updating system settings', array_slice($input, 0, 3));
    
    try {
        $db = new Database();
        $updates = [];
        $params = [];
        
        // Validate and collect updates
        if (isset($input['gps_radius_limit'])) {
            $radius = (int)$input['gps_radius_limit'];
            if ($radius < 10 || $radius > 500) {
                Logger::warn('Invalid GPS radius', ['value' => $radius]);
                http_response_code(400);
                jsonResponse(['success' => false, 'error' => 'GPS radius must be between 10 and 500 meters']);
                return;
            }
            $updates[] = 'gps_radius_limit = ?';
            $params[] = $radius;
        }
        
        if (isset($input['company_name'])) {
            $updates[] = 'company_name = ?';
            $params[] = $input['company_name'];
        }
        
        if (isset($input['currency_symbol'])) {
            if (strlen($input['currency_symbol']) > 3) {
                Logger::warn('Invalid currency symbol', ['value' => $input['currency_symbol']]);
                http_response_code(400);
                jsonResponse(['success' => false, 'error' => 'Currency symbol must be 3 characters or less']);
                return;
            }
            $updates[] = 'currency_symbol = ?';
            $params[] = $input['currency_symbol'];
        }
        
        if (isset($input['site_types'])) {
            $updates[] = 'site_types = ?';
            $params[] = json_encode($input['site_types']);
        }
        
        if (isset($input['logging_enabled'])) {
            $updates[] = 'logging_enabled = ?';
            $params[] = $input['logging_enabled'] ? 1 : 0;
            Logger::setEnabled($input['logging_enabled']);
        }
        
        if (empty($updates)) {
            http_response_code(400);
            jsonResponse(['success' => false, 'error' => 'No fields to update']);
            return;
        }
        
        // Execute update
        $params[] = 1;
        $query = 'UPDATE system_settings SET ' . implode(', ', $updates) . ' WHERE id = ?';
        $db->execute($query, $params);
        
        // Return updated settings
        $settings = $db->queryOne('SELECT * FROM system_settings LIMIT 1', []);
        Logger::info('Settings updated successfully', ['updated_fields' => count($updates)]);
        Logger::logResponse('/settings', 200);
        jsonResponse(['success' => true, 'data' => $settings ?? []]);
        
    } catch (Exception $e) {
        Logger::error('Settings update failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/settings', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * POST /login
 * User login and device binding
 */
function handleLogin($input) {
    $email = $input['email'] ?? null;
    $device_uid = $input['device_uid'] ?? null;
    
    Logger::info('Login attempt', ['email' => $email, 'device_uid' => substr($device_uid ?? '', 0, 8)]);
    
    if (!$email || !$device_uid) {
        Logger::warn('Login failed - missing credentials', ['email' => $email]);
        http_response_code(400);
        Logger::logResponse('/login', 400);
        jsonResponse(['success' => false, 'message' => 'Email and Device UID required.']);
        return;
    }
    
    try {
        // Demo user bypass
        if ($email === 'demo@quarryforce.local' || $email === 'test@quarryforce.local') {
            Logger::info('Demo user login successful', ['email' => $email]);
            Logger::logResponse('/login', 200);
            jsonResponse([
                'success' => true,
                'message' => 'Device registered successfully!',
                'user' => [
                    'id' => 1,
                    'name' => 'Demo Rep',
                    'email' => $email,
                    'role' => 'rep'
                ]
            ]);
            return;
        }
        
        $db = new Database();
        $user = $db->queryOne(
            'SELECT id, name, email, role, device_uid FROM users WHERE email = ?',
            [$email]
        );
        
        if (!$user) {
            Logger::warn('User not found', ['email' => $email]);
            Logger::logResponse('/login', 200);
            jsonResponse(['success' => false, 'message' => 'User not found. Contact admin.']);
            return;
        }
        
        // Device binding logic
        if (!$user['device_uid']) {
            // First time: bind device
            $db->execute('UPDATE users SET device_uid = ? WHERE email = ?', [$device_uid, $email]);
            Logger::info('New device bound', ['user_id' => $user['id'], 'email' => $email]);
            Logger::logResponse('/login', 200);
            jsonResponse([
                'success' => true,
                'message' => 'Device registered successfully!',
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role']
                ]
            ]);
        } else if ($user['device_uid'] === $device_uid) {
            // Returning user, same device
            Logger::info('User login successful', ['user_id' => $user['id'], 'email' => $email]);
            Logger::logResponse('/login', 200);
            jsonResponse([
                'success' => true,
                'message' => 'Login successful.',
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role']
                ]
            ]);
        } else {
            // Device mismatch
            Logger::warn('Device mismatch - security violation', [
                'user_id' => $user['id'],
                'email' => $email,
                'stored_device' => substr($user['device_uid'], 0, 8),
                'provided_device' => substr($device_uid, 0, 8)
            ]);
            Logger::logResponse('/login', 200);
            jsonResponse([
                'success' => false,
                'message' => 'Security Error: This account is locked to another device. Contact admin to reset.'
            ]);
        }
        
    } catch (Exception $e) {
        Logger::error('Login error', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/login', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * POST /checkin
 * GPS-based check-in
 */
function handleCheckin($input) {
    $rep_id = $input['rep_id'] ?? null;
    $customer_id = $input['customer_id'] ?? null;
    $rep_lat = $input['rep_lat'] ?? null;
    $rep_lng = $input['rep_lng'] ?? null;
    $device_uid = $input['device_uid'] ?? null;
    $timestamp = $input['timestamp'] ?? date('Y-m-d H:i:s');
    
    Logger::info('Check-in attempt', ['rep_id' => $rep_id, 'customer_id' => $customer_id]);
    
    // Simple device check-in (no customer)
    if ($rep_id && $device_uid && !$customer_id) {
        Logger::debug('Device check-in', ['rep_id' => $rep_id]);
        Logger::logResponse('/checkin', 200);
        jsonResponse([
            'success' => true,
            'message' => 'Check-in successful',
            'timestamp' => $timestamp
        ]);
        return;
    }
    
    // Full check-in with GPS
    if (!$rep_id || !$customer_id || $rep_lat === null || $rep_lng === null) {
        http_response_code(400);
        Logger::logResponse('/checkin', 400);
        jsonResponse(['success' => false, 'message' => 'Missing required fields.']);
        return;
    }
    
    try {
        $db = new Database();
        
        // Get GPS radius limit
        $settings = $db->queryOne(
            'SELECT gps_radius_limit FROM system_settings LIMIT 1',
            []
        );
        $allowedRadius = (int)($settings['gps_radius_limit'] ?? DEFAULT_GPS_RADIUS);
        
        // Get customer location
        $customer = $db->queryOne(
            'SELECT id, lat, lng, assigned_rep_id FROM customers WHERE id = ?',
            [$customer_id]
        );
        
        if (!$customer) {
            Logger::warn('Customer not found', ['customer_id' => $customer_id]);
            Logger::logResponse('/checkin', 200);
            jsonResponse(['success' => false, 'message' => 'Customer not found.']);
            return;
        }
        
        // Check territory ownership
        if ($customer['assigned_rep_id'] && $customer['assigned_rep_id'] != $rep_id) {
            Logger::warn('Territory protection violation', [
                'rep_id' => $rep_id,
                'customer_id' => $customer_id,
                'assigned_rep_id' => $customer['assigned_rep_id']
            ]);
            Logger::logResponse('/checkin', 200);
            jsonResponse([
                'success' => false,
                'message' => 'This location is assigned to another representative. Territory protected.'
            ]);
            return;
        }
        
        // Calculate distance (Haversine formula)
        $distance = calculateDistance(
            (float)$rep_lat,
            (float)$rep_lng,
            (float)$customer['lat'],
            (float)$customer['lng']
        );
        
        // Check if within radius
        if ($distance <= $allowedRadius) {
            Logger::info('Check-in successful', [
                'rep_id' => $rep_id,
                'customer_id' => $customer_id,
                'distance' => $distance,
                'limit' => $allowedRadius
            ]);
            Logger::logResponse('/checkin', 200);
            jsonResponse([
                'success' => true,
                'message' => "Location verified! You are {$distance}m from the site.",
                'distance' => $distance,
                'limit' => $allowedRadius
            ]);
        } else {
            Logger::warn('Check-in denied - out of range', [
                'rep_id' => $rep_id,
                'customer_id' => $customer_id,
                'distance' => $distance,
                'limit' => $allowedRadius
            ]);
            Logger::logResponse('/checkin', 200);
            jsonResponse([
                'success' => false,
                'message' => "Check-in denied. You are {$distance}m away. Limit is {$allowedRadius}m.",
                'distance' => $distance,
                'limit' => $allowedRadius
            ]);
        }
        
    } catch (Exception $e) {
        Logger::error('Check-in error', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/checkin', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * POST /visit/submit
 * Submit visit record
 */
function handleVisitSubmit($input) {
    $rep_id = $input['rep_id'] ?? null;
    $customer_id = $input['customer_id'] ?? null;
    $lat = $input['lat'] ?? null;
    $lng = $input['lng'] ?? null;
    $requirements = $input['requirements'] ?? null;
    $distance = $input['distance'] ?? null;
    
    Logger::info('Visit submission', ['rep_id' => $rep_id, 'customer_id' => $customer_id]);
    
    if (!$rep_id || !$customer_id) {
        http_response_code(400);
        Logger::logResponse('/visit/submit', 400);
        jsonResponse(['success' => false, 'message' => 'Missing required fields.']);
        return;
    }
    
    try {
        $db = new Database();
        $db->execute(
            'INSERT INTO visit_logs (customer_id, rep_id, check_in_time, requirements_json, lat_at_submission, lng_at_submission, distance_meters, gps_verified)
             VALUES (?, ?, NOW(), ?, ?, ?, ?, 1)',
            [$customer_id, $rep_id, json_encode($requirements), $lat, $lng, $distance]
        );
        
        Logger::info('Visit recorded successfully', ['rep_id' => $rep_id, 'customer_id' => $customer_id]);
        Logger::logResponse('/visit/submit', 200);
        jsonResponse(['success' => true, 'message' => 'Visit recorded successfully!']);
        
    } catch (Exception $e) {
        Logger::error('Visit submission error', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/visit/submit', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * POST /fuel/submit
 * Submit fuel log
 */
function handleFuelSubmit($input) {
    $rep_id = $input['rep_id'] ?? null;
    $odometer_reading = $input['odometer_reading'] ?? null;
    $fuel_quantity = $input['fuel_quantity'] ?? null;
    $amount = $input['amount'] ?? null;
    $lat = $input['lat'] ?? null;
    $lng = $input['lng'] ?? null;
    
    Logger::info('Fuel submission', ['rep_id' => $rep_id, 'fuel_quantity' => $fuel_quantity]);
    
    if (!$rep_id || !$odometer_reading || !$fuel_quantity) {
        http_response_code(400);
        Logger::logResponse('/fuel/submit', 400);
        jsonResponse(['success' => false, 'message' => 'Missing required fields.']);
        return;
    }
    
    try {
        $db = new Database();
        $db->execute(
            'INSERT INTO fuel_logs (rep_id, odometer_reading, fuel_quantity_liters, total_amount, lat, lng, logged_at)
             VALUES (?, ?, ?, ?, ?, ?, NOW())',
            [$rep_id, $odometer_reading, $fuel_quantity, $amount, $lat, $lng]
        );
        
        Logger::info('Fuel logged successfully', ['rep_id' => $rep_id]);
        Logger::logResponse('/fuel/submit', 200);
        jsonResponse(['success' => true, 'message' => 'Fuel log recorded successfully!']);
        
    } catch (Exception $e) {
        Logger::error('Fuel submission error', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/fuel/submit', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * GET /admin/reps
 * Get all reps
 */
function handleAdminReps() {
    Logger::debug('Fetching all reps');
    
    $demoReps = [
        [
            'id' => 1,
            'name' => 'Demo Rep',
            'email' => 'demo@quarryforce.local',
            'role' => 'rep',
            'fixed_salary' => 20000,
            'is_active' => 1,
            'phone' => null,
            'device_uid' => null
        ]
    ];
    
    try {
        $db = new Database();
        $reps = $db->query('SELECT * FROM users WHERE role IN ("rep", "admin")', []);
        Logger::logResponse('/admin/reps', 200);
        jsonResponse(['success' => true, 'data' => $reps ?? $demoReps]);
    } catch (Exception $e) {
        Logger::warn('Admin reps query failed, returning demo data', ['error' => $e->getMessage()]);
        Logger::logResponse('/admin/reps', 200);
        jsonResponse(['success' => true, 'data' => $demoReps]);
    }
}

/**
 * GET /admin/customers
 * Get all customers
 */
function handleAdminCustomers() {
    Logger::debug('Fetching all customers');
    
    $demoCustomers = [
        ['id' => 1, 'name' => 'Green Quarry Ltd', 'lat' => 12.9716, 'lng' => 77.5946, 'status' => 'active', 'assigned_rep_id' => 1, 'assigned_rep_name' => 'Demo Rep'],
        ['id' => 2, 'name' => 'Metro Limestone Co', 'lat' => 12.9352, 'lng' => 77.6245, 'status' => 'active', 'assigned_rep_id' => 1, 'assigned_rep_name' => 'Demo Rep'],
        ['id' => 3, 'name' => 'City Construction Materials', 'lat' => 13.0827, 'lng' => 80.2707, 'status' => 'active', 'assigned_rep_id' => null, 'assigned_rep_name' => null]
    ];
    
    try {
        $db = new Database();
        $customers = $db->query(
            'SELECT c.id, c.name, c.lat, c.lng, c.status, c.assigned_rep_id, u.name as assigned_rep_name
             FROM customers c
             LEFT JOIN users u ON c.assigned_rep_id = u.id',
            []
        );
        Logger::logResponse('/admin/customers', 200);
        jsonResponse(['success' => true, 'data' => $customers ?? $demoCustomers]);
    } catch (Exception $e) {
        Logger::warn('Admin customers query failed, returning demo data', ['error' => $e->getMessage()]);
        Logger::logResponse('/admin/customers', 200);
        jsonResponse(['success' => true, 'data' => $demoCustomers]);
    }
}

/**
 * POST /admin/reset-device
 * Reset device lock for a user
 */
function handleAdminResetDevice($input) {
    $user_id = $input['user_id'] ?? null;
    
    Logger::info('Device reset request', ['user_id' => $user_id]);
    
    if (!$user_id) {
        http_response_code(400);
        Logger::logResponse('/admin/reset-device', 400);
        jsonResponse(['success' => false, 'message' => 'User ID required.']);
        return;
    }
    
    try {
        $db = new Database();
        $db->execute('UPDATE users SET device_uid = NULL WHERE id = ?', [$user_id]);
        Logger::info('Device reset successful', ['user_id' => $user_id]);
        Logger::logResponse('/admin/reset-device', 200);
        jsonResponse(['success' => true, 'message' => 'Device lock reset. Rep can register a new phone.']);
    } catch (Exception $e) {
        Logger::error('Device reset failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/reset-device', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * GET /admin/rep-targets
 * Get all rep targets
 */
function handleAdminRepTargetsList() {
    Logger::debug('Fetching all rep targets');
    
    try {
        $db = new Database();
        $targets = $db->query(
            'SELECT rt.*, u.name as rep_name, u.email
             FROM rep_targets rt
             JOIN users u ON rt.rep_id = u.id
             WHERE rt.status = "active"
             ORDER BY u.name',
            []
        );
        Logger::logResponse('/admin/rep-targets', 200);
        jsonResponse(['success' => true, 'data' => $targets]);
    } catch (Exception $e) {
        Logger::error('Rep targets fetch failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/rep-targets', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * GET /admin/rep-targets/:rep_id
 * Get specific rep targets
 */
function handleAdminRepTargetsGet($repId) {
    Logger::debug('Fetching rep targets', ['rep_id' => $repId]);
    
    $demoTarget = [
        'id' => 1,
        'rep_id' => (int)$repId,
        'rep_name' => 'Demo Rep',
        'email' => 'demo@quarryforce.local',
        'target_month' => date('Y-m'),
        'monthly_sales_target_m3' => 1000,
        'incentive_rate_per_m3' => 50,
        'incentive_rate_max_per_m3' => 2000,
        'penalty_rate_per_m3' => 25,
        'status' => 'active'
    ];
    
    try {
        $db = new Database();
        $target = $db->queryOne(
            'SELECT rt.*, u.name as rep_name, u.email
             FROM rep_targets rt
             JOIN users u ON rt.rep_id = u.id
             WHERE rt.rep_id = ?',
            [$repId]
        );
        Logger::logResponse('/admin/rep-targets', 200);
        jsonResponse(['success' => true, 'data' => $target ?? $demoTarget]);
    } catch (Exception $e) {
        Logger::warn('Rep targets query failed, returning demo data', ['error' => $e->getMessage()]);
        Logger::logResponse('/admin/rep-targets', 200);
        jsonResponse(['success' => true, 'data' => $demoTarget]);
    }
}

/**
 * POST /admin/rep-targets
 * Create/set rep targets
 */
function handleAdminRepTargetsCreate($input) {
    $rep_id = $input['rep_id'] ?? null;
    $target_month = $input['target_month'] ?? null;
    $monthly_sales_target_m3 = $input['monthly_sales_target_m3'] ?? null;
    $incentive_rate_per_m3 = $input['incentive_rate_per_m3'] ?? 5;
    $incentive_rate_max_per_m3 = $input['incentive_rate_max_per_m3'] ?? 9;
    $penalty_rate_per_m3 = $input['penalty_rate_per_m3'] ?? 50;
    $updated_by = $input['updated_by'] ?? 1;
    $force_override = $input['force_override'] ?? false;
    
    Logger::info('Rep target creation request', ['rep_id' => $rep_id, 'target_m3' => $monthly_sales_target_m3]);
    
    if (!$rep_id || $monthly_sales_target_m3 === null) {
        http_response_code(400);
        Logger::logResponse('/admin/rep-targets', 400);
        jsonResponse(['success' => false, 'message' => 'rep_id and monthly_sales_target_m3 required.']);
        return;
    }
    
    try {
        $db = new Database();
        $currentMonth = $target_month ?? date('Y-m');
        
        // Check if exists
        $existing = $db->queryOne(
            'SELECT id FROM rep_targets WHERE rep_id = ? AND target_month = ?',
            [$rep_id, $currentMonth]
        );
        
        if ($existing && !$force_override) {
            http_response_code(409);
            Logger::warn('Target already exists', ['rep_id' => $rep_id, 'month' => $currentMonth]);
            Logger::logResponse('/admin/rep-targets', 409);
            jsonResponse([
                'success' => false,
                'error' => 'Target already exists for this month',
                'existingTarget' => $existing,
                'requiresConfirmation' => true
            ]);
            return;
        }
        
        // Insert or update
        $db->execute(
            'INSERT INTO rep_targets (rep_id, target_month, monthly_sales_target_m3, incentive_rate_per_m3, incentive_rate_max_per_m3, penalty_rate_per_m3, updated_by)
             VALUES (?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
             monthly_sales_target_m3 = VALUES(monthly_sales_target_m3),
             incentive_rate_per_m3 = VALUES(incentive_rate_per_m3),
             incentive_rate_max_per_m3 = VALUES(incentive_rate_max_per_m3),
             penalty_rate_per_m3 = VALUES(penalty_rate_per_m3),
             updated_by = VALUES(updated_by),
             updated_at = NOW()',
            [$rep_id, $currentMonth, $monthly_sales_target_m3, $incentive_rate_per_m3, $incentive_rate_max_per_m3, $penalty_rate_per_m3, $updated_by]
        );
        
        Logger::info('Target set successfully', ['rep_id' => $rep_id, 'target_m3' => $monthly_sales_target_m3]);
        Logger::logResponse('/admin/rep-targets', 200);
        jsonResponse(['success' => true, 'message' => 'Target set successfully!']);
        
    } catch (Exception $e) {
        Logger::error('Target creation failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/rep-targets', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * PUT /admin/rep-targets/:id
 * Update rep targets
 */
function handleAdminRepTargetsUpdate($targetId, $input) {
    Logger::info('Rep target update request', ['target_id' => $targetId]);
    
    try {
        $db = new Database();
        $updates = [];
        $params = [];
        
        if (isset($input['monthly_sales_target_m3'])) {
            $updates[] = 'monthly_sales_target_m3 = ?';
            $params[] = $input['monthly_sales_target_m3'];
        }
        if (isset($input['incentive_rate_per_m3'])) {
            $updates[] = 'incentive_rate_per_m3 = ?';
            $params[] = $input['incentive_rate_per_m3'];
        }
        if (isset($input['incentive_rate_max_per_m3'])) {
            $updates[] = 'incentive_rate_max_per_m3 = ?';
            $params[] = $input['incentive_rate_max_per_m3'];
        }
        if (isset($input['penalty_rate_per_m3'])) {
            $updates[] = 'penalty_rate_per_m3 = ?';
            $params[] = $input['penalty_rate_per_m3'];
        }
        if (isset($input['status'])) {
            $updates[] = 'status = ?';
            $params[] = $input['status'];
        }
        
        if (empty($updates)) {
            http_response_code(400);
            jsonResponse(['success' => false, 'error' => 'No fields to update']);
            return;
        }
        
        $updates[] = 'updated_by = ?';
        $params[] = $input['updated_by'] ?? 1;
        $params[] = $targetId;
        
        $db->execute(
            'UPDATE rep_targets SET ' . implode(', ', $updates) . ' WHERE id = ?',
            $params
        );
        
        Logger::info('Target updated successfully', ['target_id' => $targetId]);
        Logger::logResponse('/admin/rep-targets', 200);
        jsonResponse(['success' => true, 'message' => 'Targets updated successfully!']);
        
    } catch (Exception $e) {
        Logger::error('Target update failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/rep-targets', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * GET /admin/rep-progress/:rep_id
 * Get rep monthly progress
 */
function handleAdminRepProgress($repId, $month = null) {
    Logger::debug('Fetching rep progress', ['rep_id' => $repId, 'month' => $month]);
    
    $targetMonth = $month ?? date('Y-m-01');
    
    $demoProgress = [
        'rep_id' => (int)$repId,
        'month' => $targetMonth,
        'sales_volume_m3' => 0,
        'bonus_earned' => 0,
        'penalty_amount' => 0,
        'net_compensation' => 0,
        'status' => 'pending',
        'monthly_sales_target_m3' => 1000,
        'incentive_rate_per_m3' => 50,
        'penalty_rate_per_m3' => 25,
        'rep_name' => 'Demo Rep'
    ];
    
    try {
        $db = new Database();
        $progress = $db->queryOne(
            'SELECT rp.*, rt.monthly_sales_target_m3, rt.incentive_rate_per_m3, rt.penalty_rate_per_m3, u.name as rep_name
             FROM rep_progress rp
             LEFT JOIN rep_targets rt ON rp.rep_id = rt.rep_id
             LEFT JOIN users u ON rp.rep_id = u.id
             WHERE rp.rep_id = ? AND rp.month = ?',
            [$repId, $targetMonth]
        );
        
        if (!$progress) {
            Logger::debug('No progress found, checking targets', ['rep_id' => $repId]);
            $target = $db->queryOne(
                'SELECT rt.*, u.name as rep_name FROM rep_targets rt
                 JOIN users u ON rt.rep_id = u.id
                 WHERE rt.rep_id = ?',
                [$repId]
            );
            Logger::logResponse('/admin/rep-progress', 200);
            jsonResponse([
                'success' => true,
                'data' => [
                    'rep_id' => $repId,
                    'month' => $targetMonth,
                    'sales_volume_m3' => 0,
                    'bonus_earned' => 0,
                    'penalty_amount' => 0,
                    'net_compensation' => 0,
                    'status' => 'pending',
                    'targets' => $target
                ]
            ]);
            return;
        }
        
        Logger::logResponse('/admin/rep-progress', 200);
        jsonResponse(['success' => true, 'data' => $progress]);
        
    } catch (Exception $e) {
        Logger::warn('Rep progress query failed, returning demo data', ['error' => $e->getMessage()]);
        Logger::logResponse('/admin/rep-progress', 200);
        jsonResponse(['success' => true, 'data' => $demoProgress]);
    }
}

/**
 * GET /admin/rep-progress-history/:rep_id
 * Get all historical progress for a rep
 */
function handleAdminRepProgressHistory($repId) {
    Logger::debug('Fetching rep progress history', ['rep_id' => $repId]);
    
    try {
        $db = new Database();
        $history = $db->query(
            'SELECT rp.*, u.name as rep_name
             FROM rep_progress rp
             LEFT JOIN users u ON rp.rep_id = u.id
             WHERE rp.rep_id = ?
             ORDER BY rp.month DESC',
            [$repId]
        );
        Logger::logResponse('/admin/rep-progress-history', 200);
        jsonResponse(['success' => true, 'data' => $history]);
    } catch (Exception $e) {
        Logger::error('Progress history fetch failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/rep-progress-history', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * POST /admin/rep-progress/update
 * Update rep sales and calculate bonus/penalty
 */
function handleAdminRepProgressUpdate($input) {
    $rep_id = $input['rep_id'] ?? null;
    $sales_volume_m3 = $input['sales_volume_m3'] ?? null;
    $month = $input['month'] ?? null;
    
    Logger::info('Rep progress update request', ['rep_id' => $rep_id, 'sales_volume_m3' => $sales_volume_m3]);
    
    if (!$rep_id || $sales_volume_m3 === null) {
        http_response_code(400);
        Logger::logResponse('/admin/rep-progress/update', 400);
        jsonResponse(['success' => false, 'message' => 'rep_id and sales_volume_m3 required.']);
        return;
    }
    
    try {
        $db = new Database();
        $targetMonth = $month ?? date('Y-m-01');
        
        // Get rep targets
        $target = $db->queryOne(
            'SELECT * FROM rep_targets WHERE rep_id = ?',
            [$rep_id]
        );
        
        if (!$target) {
            Logger::warn('Targets not found for rep', ['rep_id' => $rep_id]);
            http_response_code(400);
            Logger::logResponse('/admin/rep-progress/update', 400);
            jsonResponse(['success' => false, 'message' => 'Targets not found for this rep.']);
            return;
        }
        
        // Calculate bonus/penalty
        $bonus = 0;
        $penalty = 0;
        
        if ($sales_volume_m3 > $target['monthly_sales_target_m3']) {
            $excess = $sales_volume_m3 - $target['monthly_sales_target_m3'];
            $bonus = $excess * $target['incentive_rate_per_m3'];
        } else if ($sales_volume_m3 < $target['monthly_sales_target_m3']) {
            $shortfall = $target['monthly_sales_target_m3'] - $sales_volume_m3;
            $penalty = $shortfall * $target['penalty_rate_per_m3'];
        }
        
        $netComp = $bonus - $penalty;
        
        // Insert/update progress
        $db->execute(
            'INSERT INTO rep_progress (rep_id, month, sales_volume_m3, bonus_earned, penalty_amount, net_compensation)
             VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
             sales_volume_m3 = VALUES(sales_volume_m3),
             bonus_earned = VALUES(bonus_earned),
             penalty_amount = VALUES(penalty_amount),
             net_compensation = VALUES(net_compensation)',
            [$rep_id, $targetMonth, $sales_volume_m3, $bonus, $penalty, $netComp]
        );
        
        Logger::info('Progress updated with bonus/penalty calculation', [
            'rep_id' => $rep_id,
            'sales' => $sales_volume_m3,
            'bonus' => $bonus,
            'penalty' => $penalty
        ]);
        
        Logger::logResponse('/admin/rep-progress/update', 200);
        jsonResponse([
            'success' => true,
            'message' => 'Progress updated successfully!',
            'data' => [
                'rep_id' => $rep_id,
                'month' => $targetMonth,
                'sales_volume_m3' => $sales_volume_m3,
                'bonus_earned' => $bonus,
                'penalty_amount' => $penalty,
                'net_compensation' => $netComp,
                'target_m3' => $target['monthly_sales_target_m3'],
                'status' => 'pending'
            ]
        ]);
        
    } catch (Exception $e) {
        Logger::error('Progress update failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/rep-progress/update', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * GET /admin/users
 * Get all users
 */
function handleAdminUsersList() {
    Logger::debug('Fetching all users');
    
    try {
        $db = new Database();
        $users = $db->query(
            'SELECT id, email, name, role, device_uid, is_active, fixed_salary, created_at FROM users ORDER BY created_at DESC',
            []
        );
        Logger::logResponse('/admin/users', 200);
        jsonResponse(['success' => true, 'data' => $users]);
    } catch (Exception $e) {
        Logger::error('Users fetch failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/users', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * POST /admin/users
 * Create new user
 */
function handleAdminUsersCreate($input) {
    $email = $input['email'] ?? null;
    $name = $input['name'] ?? null;
    
    Logger::info('User creation request', ['email' => $email, 'name' => $name]);
    
    if (!$email || !$name) {
        http_response_code(400);
        Logger::logResponse('/admin/users', 400);
        jsonResponse(['success' => false, 'message' => 'Email and name are required.']);
        return;
    }
    
    try {
        $db = new Database();
        
        // Check if exists
        $existing = $db->queryOne('SELECT id FROM users WHERE email = ?', [$email]);
        if ($existing) {
            http_response_code(400);
            Logger::warn('User already exists', ['email' => $email]);
            Logger::logResponse('/admin/users', 400);
            jsonResponse(['success' => false, 'message' => 'User with this email already exists.']);
            return;
        }
        
        // Create user
        $db->execute(
            'INSERT INTO users (email, name, role, is_active) VALUES (?, ?, ?, ?)',
            [$email, $name, 'rep', 1]
        );
        
        $userId = $db->lastId();
        Logger::info('User created successfully', ['user_id' => $userId, 'email' => $email]);
        Logger::logResponse('/admin/users', 200);
        jsonResponse([
            'success' => true,
            'message' => 'User created successfully!',
            'data' => ['id' => $userId, 'email' => $email, 'name' => $name, 'role' => 'rep']
        ]);
        
    } catch (Exception $e) {
        Logger::error('User creation failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/users', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * PUT /admin/users/:id
 * Update user
 */
function handleAdminUsersUpdate($userId, $input) {
    $email = $input['email'] ?? null;
    $name = $input['name'] ?? null;
    $fixed_salary = $input['fixed_salary'] ?? null;
    
    Logger::info('User update request', ['user_id' => $userId, 'email' => $email]);
    
    if (!$email || !$name) {
        http_response_code(400);
        Logger::logResponse('/admin/users', 400);
        jsonResponse(['success' => false, 'message' => 'Email and name are required.']);
        return;
    }
    
    try {
        $db = new Database();
        $updates = ['email = ?', 'name = ?'];
        $params = [$email, $name];
        
        if ($fixed_salary !== null) {
            $updates[] = 'fixed_salary = ?';
            $params[] = $fixed_salary;
        }
        
        $params[] = $userId;
        $db->execute('UPDATE users SET ' . implode(', ', $updates) . ' WHERE id = ?', $params);
        
        Logger::info('User updated successfully', ['user_id' => $userId]);
        Logger::logResponse('/admin/users', 200);
        jsonResponse(['success' => true, 'message' => 'User updated successfully!']);
        
    } catch (Exception $e) {
        Logger::error('User update failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/users', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * DELETE /admin/users/:id
 * Delete user
 */
function handleAdminUsersDelete($userId) {
    Logger::info('User deletion request', ['user_id' => $userId]);
    
    try {
        $db = new Database();
        $db->execute('DELETE FROM users WHERE id = ?', [$userId]);
        
        Logger::info('User deleted successfully', ['user_id' => $userId]);
        Logger::logResponse('/admin/users', 200);
        jsonResponse(['success' => true, 'message' => 'User deleted successfully!']);
        
    } catch (Exception $e) {
        Logger::error('User deletion failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/users', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * PUT /admin/users/:id/device-uid
 * Set device UID for user
 */
function handleAdminUsersSetDevice($userId, $input) {
    $device_uid = $input['device_uid'] ?? null;
    
    Logger::info('Device UID update request', ['user_id' => $userId]);
    
    if (!$device_uid) {
        http_response_code(400);
        Logger::logResponse('/admin/users', 400);
        jsonResponse(['success' => false, 'message' => 'Device UID is required.']);
        return;
    }
    
    try {
        $db = new Database();
        $db->execute('UPDATE users SET device_uid = ? WHERE id = ?', [$device_uid, $userId]);
        
        Logger::info('Device UID updated successfully', ['user_id' => $userId]);
        Logger::logResponse('/admin/users', 200);
        jsonResponse(['success' => true, 'message' => 'Device UID updated successfully!']);
        
    } catch (Exception $e) {
        Logger::error('Device UID update failed', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/admin/users', 500);
        jsonResponse(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * GET /test
 * Health check
 */
function handleTest() {
    Logger::debug('Health check requested');
    
    try {
        $db = new Database();
        if ($db->isConnected()) {
            Logger::logResponse('/test', 200);
            jsonResponse(['server' => 'Online', 'database' => 'Connected', 'version' => '2.0.0']);
        } else {
            Logger::warn('Database not connected');
            http_response_code(500);
            Logger::logResponse('/test', 500);
            jsonResponse(['server' => 'Online', 'database' => 'Error', 'error' => 'Database connection failed']);
        }
    } catch (Exception $e) {
        Logger::error('Health check error', ['error' => $e->getMessage()]);
        http_response_code(500);
        Logger::logResponse('/test', 500);
        jsonResponse(['server' => 'Online', 'database' => 'Error', 'error' => $e->getMessage()]);
    }
}

// ==========================================
// UTILITIES
// ==========================================

/**
 * Send JSON response
 */
function jsonResponse($data) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

/**
 * Calculate distance between two points using Haversine formula
 * Returns distance in meters
 */
function calculateDistance($lat1, $lon1, $lat2, $lon2) {
    $earthRadius = 6371000; // meters
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat / 2) * sin($dLat / 2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon / 2) * sin($dLon / 2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    $distance = $earthRadius * $c;
    return round($distance); // Return as integer meters
}

?>
