================================================================================
QUARRYFORCE DEPLOYMENT CHECKLIST - STEP-BY-STEP INSTRUCTIONS
================================================================================

# SECTION 1: PREPARE THE DEPLOYMENT PACKAGE (LOCAL MACHINE)

[ ] Step 1: Open Command Prompt in the deployment folder
Command: cd d:\quarryforce\qft-deployment

[ ] Step 2: Install Node.js dependencies (creates node_modules folder)
Command: npm install
Note: This will take 2-3 minutes. Downloads ~125MB of packages.

[ ] Step 3: Create .env file with actual database credentials - Copy .env.template to create .env file - Open .env and update these values:
DB_HOST=localhost
DB_USER=quarryforce_user  
 DB_PASSWORD=[YOUR ACTUAL PASSWORD]
DB_NAME=quarryforce_db - Save the file
WARNING: Do NOT commit .env to Git. Keep it local only.

[ ] Step 4: Verify qft-deployment folder contains:
✓ index.js
✓ db.js
✓ package.json
✓ .env (with your credentials)
✓ .env.template
✓ .htaccess
✓ admin/ (folder with React dashboard files)
✓ node_modules/ (folder with dependencies)
✓ uploads/ (empty folder for file uploads)
✓ DEPLOYMENT_FOLDER_STRUCTURE.txt

[ ] Step 5: ZIP the complete qft-deployment folder - Right-click qft-deployment folder - Select "Send to" > "Compressed (zipped) folder" - Result: qft-deployment.zip file created
Note: File size should be ~140-150 MB (includes node_modules)

================================================================================
SECTION 2: UPLOAD TO SERVER (CPANEL)
================================================================================

[ ] Step 1: Login to cPanel
URL: https://cpanel.valviyal.com/ (or your cPanel URL)
Username: brutsaxr
Password: [Your cPanel password]

[ ] Step 2: Open File Manager - Click "File Manager" in cPanel - Select "Public HTML" folder - Click "Go"

[ ] Step 3: Upload qft-deployment.zip - Click "Upload" button - Select qft-deployment.zip file from your computer - Wait for upload to complete (5-10 minutes for 140MB file) - Verify file appears in /public_html/

[ ] Step 4: Extract the ZIP file - Right-click qft-deployment.zip - Select "Extract" - Click "Extract File(s)" - Wait for extraction (1-2 minutes) - Verify /public_html/qft-deployment/ folder is created

================================================================================
SECTION 3: REORGANIZE FOLDER STRUCTURE (CPANEL)
================================================================================

[ ] Step 1: Navigate into qft-deployment folder - Click on qft-deployment folder to open it

[ ] Step 2: Select ALL files in qft-deployment - Click checkbox at top to "Select All" - Should select 8 items (index.js, db.js, package.json, etc.)

[ ] Step 3: Cut the files - Right-click selected files - Click "Cut"

[ ] Step 4: Go back to public_html folder - Click "public_html" in the breadcrumb navigation - Or click back button to go up one level

[ ] Step 5: Create new folder "qft" - Right-click in empty space - Select "Create New" > "Folder" - Name: qft - Click "Create New Folder"

[ ] Step 6: Enter qft folder and paste files - Double-click qft folder to open it - Right-click in empty space - Select "Paste" - Wait for files to paste (should be quick)

[ ] Step 7: Verify qft folder contains ALL files:
✓ index.js
✓ db.js
✓ package.json
✓ .env
✓ .env.template
✓ .htaccess
✓ admin/ (folder)
✓ node_modules/ (folder)
✓ uploads/ (folder)

[ ] Step 8: Delete the empty qft-deployment folder - Go back to public_html - Right-click qft-deployment folder - Select "Delete" - Confirm deletion - Delete qft-deployment.zip file too (optional, to save space)

================================================================================
SECTION 4: RESTART THE NODE.JS APPLICATION
================================================================================

[ ] Step 1: Go to Node.js Selector in cPanel - Click "Node.js Selector" in cPanel - Or search for "Node.js" in cPanel search bar

[ ] Step 2: Find your application - Look for application on /home/brutsaxr/public_html/qft - Click on it to select it

[ ] Step 3: Restart the application - Click "RESTART" button - Wait 1-2 minutes for restart to complete - Status should change to "Running"

[ ] Step 4: Verify application is running - Check status shows "Running" - Note the port number assigned

================================================================================
SECTION 5: TEST THE DEPLOYMENT
================================================================================

[ ] Step 1: Test in browser
URL: https://valviyal.com/qft/ - Hard refresh: Ctrl+F5 (or Cmd+Shift+R on Mac) - Should see QuarryForce Dashboard loading

[ ] Step 2: Test API endpoints
Root API: https://valviyal.com/qft/api/settings - Should return JSON response with system settings

     Login Test: POST https://valviyal.com/qft/api/login
     - Email: demo@quarryforce.local
     - Device UID: test-device-123
     - Should return successful login response

[ ] Step 3: Check admin dashboard
URL: https://valviyal.com/qft/admin/ - Should see admin login page - Try connecting to validate React app is working

[ ] Step 4: Check server logs (if available) - Go back to cPanel > Node.js Selector - Click on your application - Look for "View Logs" or "Output" section - Check for any error messages

================================================================================
TROUBLESHOOTING SECTION
================================================================================

PROBLEM: "Cannot find module 'mysql2'"
SOLUTION:

- SSH into server: ssh brutsaxr@valviyal.com
- cd /home/brutsaxr/public_html/qft
- Run: npm install
- Wait for completion

PROBLEM: Database connection failed
SOLUTION:

- Verify .env file has correct database credentials
- Check database is running on server
- Verify user "quarryforce_user" exists in MySQL
- Try: mysql -u quarryforce_user -p quarryforce_db

PROBLEM: 404 errors on /qft/\* pages
SOLUTION:

- Check .htaccess file is in /public_html/qft/
- Check apache mod_rewrite is enabled
- Restart Node.js app again

PROBLEM: Admin dashboard returns blank page
SOLUTION:

- Check admin/index.html exists
- Check admin/static/js/ and admin/static/css/ folders exist
- Hard refresh browser: Ctrl+F5
- Check browser console for errors (F12)

PROBLEM: Application crashes after 5-10 minutes
SOLUTION:

- Likely database connection timeout
- Check database server is running
- Check firewall allows MySQL connection
- Ask support@valviyal.com for help

================================================================================
SECTION 6: POST-DEPLOYMENT CONFIGURATION
================================================================================

[ ] Step 1: Create .env file on server (if not already done) - Via cPanel File Manager: Create/Edit - Or via SSH: nano /home/brutsaxr/public_html/qft/.env - Copy contents from .env.template - Update with real database credentials - Save file

[ ] Step 2: Verify environment variables are set
Command (via SSH): cat /home/brutsaxr/public_html/qft/.env
Should show:
NODE_ENV=production
PORT=3000
DB_HOST=localhost
DB_USER=quarryforce_user
DB_PASSWORD=\*\*\*
DB_NAME=quarryforce_db

[ ] Step 3: Set proper file permissions (if using SSH)
chmod 644 /home/brutsaxr/public_html/qft/.env
chmod 755 /home/brutsaxr/public_html/qft/uploads

[ ] Step 4: Configure database if first deployment - Run migration scripts (if not already done) - Create required tables - Load initial data - See SYSTEM_ARCHITECTURE_GUIDE.md for DB schema

================================================================================
FINAL VERIFICATION CHECKLIST
================================================================================

After completing all steps above, verify:

[ ] Application is running at https://valviyal.com/qft/
[ ] Root API endpoint returns success: https://valviyal.com/qft/api/settings
[ ] Login API works: POST /api/login
[ ] Admin dashboard loads: https://valviyal.com/qft/admin/
[ ] No "Module not found" errors in logs
[ ] No database connection errors
[ ] React app loads without blank page
[ ] API endpoints respond with JSON data
[ ] File uploads work in uploads/ folder
[ ] .htaccess is properly routing requests

================================================================================
IMPORTANT NOTES
================================================================================

• NEVER commit .env to Git - it contains database passwords
• Always backup existing application before deploying new version
• Test in staging environment first if possible
• Keep node_modules folder - it's required for production
• Monitor logs regularly for errors
• If deployment fails, contact support@valviyal.com

SUPPORT CONTACT:
Email: support@valviyal.com
Phone: [Your phone number]
Hours: Business hours IST (UTC+5:30)

================================================================================
